package com.example.pritam.myprofile

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    var photo : ImageView? = null
            var edubutton : Button?=null
    var workbutton :Button?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        photo=findViewById(R.id.profile_photo)
        photo?.setOnClickListener({ var clickIntent = Intent(this@MainActivity,ProfilePhoto::class.java)
            startActivity(clickIntent)})
        edubutton=findViewById(R.id.education)
        edubutton?.setOnClickListener({ var clickIntent = Intent(this@MainActivity,Education::class.java)
            startActivity(clickIntent)})
        workbutton=findViewById(R.id.work_experience)
        workbutton?.setOnClickListener({ var clickIntent = Intent(this@MainActivity,WorkExperience::class.java)
            startActivity(clickIntent)})

    }
}
